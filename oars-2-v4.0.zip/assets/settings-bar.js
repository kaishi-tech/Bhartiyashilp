class SettingsBar {
  constructor() {
    const layout = document.querySelector('[data-settings-bar-layout]');
    const body = document.querySelector('body');
    this.loadData();

    document.querySelectorAll('[data-settings-bar-color]').forEach(
      (color) => color.addEventListener('click', this.setColor.bind(this))
    );
  }
  
  setColor(event) {
    event.preventDefault();
    const color = event.currentTarget.dataset.settingsBarColor;
    localStorage.setItem('color-storage', color);
    this.loadColor(color);
  }

  loadData() {
	const color = localStorage.getItem('color-storage');
    if(color != null) {
      this.loadColor(color);
    }
  }
  
  loadColor(color) {
    document.querySelectorAll('[data-settings-bar-color]').forEach(
      (color) => {color.classList.remove('is-active')}
    );
    document.querySelector(`[data-settings-bar-color="${color}"]`).classList.add('is-active');
    
	document.documentElement.style.setProperty('--color_primary', color);
    document.documentElement.style.setProperty('--color_dropdown_text_hover', color);
    document.documentElement.style.setProperty('--color_navigation_text_hover', color);
    document.documentElement.style.setProperty('--color_product_hover', color);
    document.documentElement.style.setProperty('--color_btn_border', color);
    document.documentElement.style.setProperty('--color_btn_bg', color);	
    document.documentElement.style.setProperty('--color_footer_text_hover', color);
    document.documentElement.style.setProperty('--color_copyright_text_hover', color);
    document.documentElement.style.setProperty('--top-header-search-text', color);
    document.documentElement.style.setProperty('--color_header_bg', color);
    document.documentElement.style.setProperty('--color_btnnewsletter_border', color);
    document.documentElement.style.setProperty('--color_btnnewsletter_bg', color);
  }
}

new SettingsBar();