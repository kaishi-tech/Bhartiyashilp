class SlideshowParallax {
  constructor() {
    $(window).scroll((event) => {
      const h = $(window).innerHeight();
      const $this = $(event.currentTarget);
      const scrollTop = $this.scrollTop();
      if (scrollTop <= h) {
        const transY = scrollTop / 2;
        const transform = `translateY(${transY}px)`;
        $('.index-slideshow-parallax').css('transform', transform);
      }

      if (scrollTop > 10) {
        $('.icon-scroll').hide('500');
      } else {
        $('.icon-scroll').show('500');
      }
    });
  }
}

new SlideshowParallax();