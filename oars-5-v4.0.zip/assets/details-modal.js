class DetailsModal extends HTMLElement {
  constructor() {
    super();
    this.detailsContainer = this.querySelector('details');
    this.summaryToggle = this.querySelector('summary');
    this.focus =  this.detailsContainer.dataset.focus;
    this.overflow = true;
    if (this.dataset.overflow) this.overflow = this.dataset.overflow;

    this.detailsContainer.addEventListener(
      'keyup',
      (event) => {
        if(!event.code) return;
        if(event.code.toUpperCase() === 'ESCAPE') this.close();
      }
    );
    this.summaryToggle.addEventListener(
      'click',
      this.onSummaryClick.bind(this)
    );
    this.querySelector('button[type="button"]').addEventListener(
      'click',
      this.close.bind(this)
    );

    this.summaryToggle.setAttribute('role', 'button');
  }

  isOpen() {
    return this.detailsContainer.hasAttribute('open');
  }

  onSummaryClick(event) {
    event.preventDefault();
    event.target.closest('details').hasAttribute('open')
      ? this.close()
      : this.open(event);
  }

  onBodyClick(event) {
    if (!this.contains(event.target) || event.target.classList.contains('header-drawer__overlay')) this.close(false);
  }

  open(event) {
    this.onBodyClickEvent =
      this.onBodyClickEvent || this.onBodyClick.bind(this);
    setTimeout(() => {
      this.detailsContainer.classList.add('menu-opening');
      if (this.detailsContainer.querySelector('input:not([type="hidden"])') && this.focus == 'true') {
        trapFocus(
          this.detailsContainer.querySelector('[tabindex="-1"]'),
          this.detailsContainer.querySelector('input:not([type="hidden"])')
        );
      }
    });
    event.target.closest('details').setAttribute('open', true);
    document.body.addEventListener('click', this.onBodyClickEvent);
	if (this.overflow == true || this.overflow == 'true') document.body.classList.add('overflow-hidden'); 
  }

  close(focusToggle = true) {
    removeTrapFocus(focusToggle ? this.summaryToggle : null);
    setTimeout(() => {
      this.detailsContainer.classList.remove('menu-opening');
    });

    document.body.removeEventListener('click', this.onBodyClickEvent);
    if (this.overflow == true || this.overflow == 'true') document.body.classList.remove('overflow-hidden');
    this.closeAnimation(this.detailsContainer);
  }
  closeAnimation(detailsElement) {
    let animationStart;

    const handleAnimation = (time) => {
      if (animationStart === undefined) {
        animationStart = time;
      }

      const elapsedTime = time - animationStart;

      if (elapsedTime < 400) {
        window.requestAnimationFrame(handleAnimation);
      } else {
        detailsElement.removeAttribute('open');
        if (detailsElement.closest('details[open]')) {
          trapFocus(detailsElement.closest('details[open]'), detailsElement.querySelector('summary'));
        }
      }
    }

    window.requestAnimationFrame(handleAnimation);
  }
}

customElements.define('details-modal', DetailsModal);
